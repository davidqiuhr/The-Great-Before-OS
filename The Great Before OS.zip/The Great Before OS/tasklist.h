#pragma once

extern struct Keyboard keyboard;
extern struct Window window;

void taskListTask_Main(struct Task *task); 
void showTask(struct Sheet *taskListSheet);
