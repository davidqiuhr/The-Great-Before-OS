#pragma once

extern struct Keyboard keyboard;
extern struct Window window;
void imageViewerTask_Main(struct Task *task);