#pragma once

void openFile(char *fileName);